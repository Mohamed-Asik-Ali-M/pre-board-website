<?php
// Simple user search by roll number
?>
<!doctype html><html><head><meta charset="utf-8"><title>User Panel</title><link rel="stylesheet" href="../style.css"></head>
<body><div class="box"><h2>Student Result</h2>
<form action="view_result.php" method="get">
<label>Roll Number<br><input name="roll_no"></label><br>
<button>View Result</button>
</form>
<p><a href="../admin/index.php">Admin Login</a></p>
</div></body></html>
