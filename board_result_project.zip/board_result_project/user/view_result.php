<?php
require 'config.php';
$roll = $mysqli->real_escape_string($_GET['roll_no'] ?? '');
$student = null;
$results = [];
if ($roll) {
    $res = $mysqli->query("SELECT * FROM students WHERE roll_no='{$roll}' LIMIT 1");
    if ($res->num_rows) {
        $student = $res->fetch_assoc();
        $rid = intval($student['id']);
        $rres = $mysqli->query("SELECT subject,marks,total FROM results WHERE student_id={$rid}");
        while($row = $rres->fetch_assoc()) $results[] = $row;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>View Result</title><link rel="stylesheet" href="../style.css"></head>
<body><div class="box">
<?php if(!$student): ?>
<p>Enter a valid roll number.</p>
<form action="view_result.php" method="get">
<label>Roll Number<br><input name="roll_no" value="<?=htmlspecialchars($roll)?>"></label><br>
<button>View Result</button>
</form>
<?php else: ?>
<h2>Marksheet for <?=htmlspecialchars($student['name'])?> (Roll <?=htmlspecialchars($student['roll_no'])?>)</h2>
<table border="1" cellpadding="6"><tr><th>Subject</th><th>Marks</th><th>Total</th></tr>
<?php foreach($results as $r): ?>
<tr><td><?=htmlspecialchars($r['subject'])?></td><td><?=htmlspecialchars($r['marks'])?></td><td><?=htmlspecialchars($r['total'])?></td></tr>
<?php endforeach; ?>
</table>
<p>
<!-- Download as PDF: opens printable page; user can Save as PDF in browser -->
<a href="download_pdf.php?roll_no=<?=urlencode($student['roll_no'])?>" target="_blank">Open printable marksheet (Save as PDF)</a>
</p>
<?php endif; ?>
<p><a href="index.php">Back</a></p>
</div></body></html>
