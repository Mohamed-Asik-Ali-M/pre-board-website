<?php
require 'config.php';
$roll = $mysqli->real_escape_string($_GET['roll_no'] ?? '');
$student = null;
$results = [];
if ($roll) {
    $res = $mysqli->query("SELECT * FROM students WHERE roll_no='{$roll}' LIMIT 1");
    if ($res->num_rows) {
        $student = $res->fetch_assoc();
        $rid = intval($student['id']);
        $rres = $mysqli->query("SELECT subject,marks,total FROM results WHERE student_id={$rid}");
        while($row = $rres->fetch_assoc()) $results[] = $row;
    } else {
        die('Student not found');
    }
} else die('No roll provided');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Marksheet Print</title>
<link rel="stylesheet" href="../style.css">
<style>@media print{ .no-print{display:none;} }</style>
</head><body>
<div style="max-width:800px;margin:0 auto;padding:20px;border:1px solid #333;">
<h1 style="text-align:center">SCHOOL NAME</h1>
<h3 style="text-align:center">Marksheet</h3>
<p><strong>Name:</strong> <?=htmlspecialchars($student['name'])?><br>
<strong>Roll:</strong> <?=htmlspecialchars($student['roll_no'])?></p>
<table border="1" cellpadding="6" style="width:100%"><tr><th>Subject</th><th>Marks</th><th>Total</th></tr>
<?php foreach($results as $r): ?>
<tr><td><?=htmlspecialchars($r['subject'])?></td><td><?=htmlspecialchars($r['marks'])?></td><td><?=htmlspecialchars($r['total'])?></td></tr>
<?php endforeach; ?>
</table>
<p class="no-print"><button onclick="window.print()">Print / Save as PDF</button></p>
</div>
</body></html>
