<?php
session_start();
if (!isset($_SESSION['admin'])) { header('Location: index.php'); exit; }
require 'config.php';

$message = '';
if (isset($_POST['import'])) {
    $mode = $_POST['mode'] ?? 'url';
    $csv = '';
    if ($mode === 'url') {
        $url = trim($_POST['csv_url'] ?? '');
        if ($url) {
            // fetch CSV using file_get_contents or cURL
            $opts = stream_context_create(['http'=>['timeout'=>10]]);
            $csv = @file_get_contents($url, false, $opts);
            if ($csv === false) $message = "Failed to fetch CSV from URL.";
        } else $message = "Enter CSV URL.";
    } else {
        $csv = trim($_POST['csv_text'] ?? '');
        if (!$csv) $message = "Paste CSV text or choose URL.";
    }
    if ($csv) {
        // parse CSV
        $lines = array_map('trim', explode("\n", $csv));
        $rows = [];
        foreach ($lines as $line) {
            if ($line === '') continue;
            // use str_getcsv to support commas inside quotes
            $rows[] = str_getcsv($line);
        }
        // expected columns: roll_no,name,class,subject,marks,total,percentage,grade
        $count = 0;
        foreach ($rows as $r) {
            if (count($r) < 6) continue;
            $roll = $mysqli->real_escape_string($r[0]);
            $name = $mysqli->real_escape_string($r[1]);
            $class = $mysqli->real_escape_string($r[2]);
            $subject = $mysqli->real_escape_string($r[3]);
            $marks = intval($r[4]);
            $total = intval($r[5]);
            // ensure student exists
            $res = $mysqli->query("SELECT id FROM students WHERE roll_no='{$roll}' LIMIT 1");
            if ($res->num_rows) {
                $sid = $res->fetch_assoc()['id'];
            } else {
                $mysqli->query("INSERT INTO students (roll_no,name,class) VALUES ('{$roll}','{$name}','{$class}')");
                $sid = $mysqli->insert_id;
            }
            // insert result
            $mysqli->query("INSERT INTO results (student_id,subject,marks,total) VALUES ({$sid},'{$subject}',{$marks},{$total})");
            $count++;
        }
        $message = "Imported {$count} rows.";
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Import from Google Sheet</title><link rel="stylesheet" href="../style.css"></head>
<body><div class="box"><h2>Import from Google Sheet (CSV)</h2>
<p>Option A (recommended): publish your Google Sheet to web as CSV and paste the CSV URL here.<br>
Option B: copy CSV text and paste below.</p>
<?php if($message) echo "<p class='info'>".htmlspecialchars($message)."</p>"; ?>
<form method="post">
<label><input type="radio" name="mode" value="url" checked> CSV URL</label><br>
<input name="csv_url" placeholder="https://docs.google.com/spreadsheets/d/XXXXX/export?format=csv&id=XXXXX&gid=0" style="width:100%"><br><br>
<label><input type="radio" name="mode" value="text"> Paste CSV text</label><br>
<textarea name="csv_text" rows="8" style="width:100%"></textarea><br>
<button name="import">Import</button>
</form>
<p><a href="dashboard.php">Back</a></p>
</div></body></html>
