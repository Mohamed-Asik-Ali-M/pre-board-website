<?php
session_start();
if (!isset($_SESSION['admin'])) { header('Location: index.php'); exit; }
require 'config.php';
$res = $mysqli->query("SELECT r.id, s.roll_no, s.name, r.subject, r.marks, r.total FROM results r JOIN students s ON r.student_id = s.id ORDER BY s.roll_no, r.id");
?>
<!doctype html><html><head><meta charset="utf-8"><title>View Results</title><link rel="stylesheet" href="../style.css"></head>
<body><div class="box"><h2>All Results</h2>
<table border="1" cellpadding="6"><tr><th>Roll</th><th>Name</th><th>Subject</th><th>Marks</th><th>Total</th><th>Action</th></tr>
<?php while($row = $res->fetch_assoc()): ?>
<tr>
<td><?=htmlspecialchars($row['roll_no'])?></td>
<td><?=htmlspecialchars($row['name'])?></td>
<td><?=htmlspecialchars($row['subject'])?></td>
<td><?=htmlspecialchars($row['marks'])?></td>
<td><?=htmlspecialchars($row['total'])?></td>
<td><a href="delete_result.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete?')">Delete</a></td>
</tr>
<?php endwhile; ?>
</table>
<p><a href="dashboard.php">Back</a></p>
</div></body></html>
