<?php
session_start();
if (isset($_POST['login'])) {
    $user = $_POST['user'] ?? '';
    $pass = $_POST['pass'] ?? '';
    // Simple hardcoded admin. Change as needed.
    if ($user === 'admin' && $pass === 'admin123') {
        $_SESSION['admin'] = true;
        header('Location: dashboard.php'); exit;
    } else {
        $err = "Invalid credentials";
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin Login</title><link rel="stylesheet" href="../style.css"></head>
<body><div class="box"><h2>Admin Login</h2>
<?php if(!empty($err)) echo "<p class='err'>$err</p>"; ?>
<form method="post">
<label>Username<br><input name="user"></label><br>
<label>Password<br><input name="pass" type="password"></label><br>
<button name="login">Login</button>
</form>
<p><a href="../user/index.php">Go to User Panel</a></p>
</div></body></html>
