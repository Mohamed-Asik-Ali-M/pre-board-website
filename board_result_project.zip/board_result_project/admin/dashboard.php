<?php
session_start();
if (!isset($_SESSION['admin'])) { header('Location: index.php'); exit; }
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="../style.css"></head>
<body><div class="box"><h2>Admin Dashboard</h2>
<ul>
<li><a href="import_sheet.php">Import from Google Sheet (CSV or published)</a></li>
<li><a href="view_results.php">View Results</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div></body></html>
