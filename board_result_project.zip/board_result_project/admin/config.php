<?php
// Database config - set these values after importing database.sql
$DB_HOST = "localhost";
$DB_USER = "board_user";
$DB_PASS = "StrongDBpass!";
$DB_NAME = "board_results";

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_error) {
    die("DB Connection failed: " . $mysqli->connect_error);
}
?>
