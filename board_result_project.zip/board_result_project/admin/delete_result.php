<?php
session_start();
if (!isset($_SESSION['admin'])) { header('Location: index.php'); exit; }
require 'config.php';
$id = intval($_GET['id'] ?? 0);
if ($id) {
    $stmt = $mysqli->prepare("DELETE FROM results WHERE id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
}
header('Location: view_results.php');
?>