
Simplified Board Result Project
--------------------------------
1) Import database.sql into phpMyAdmin (http://localhost/phpmyadmin).
2) Place folder 'board_result_project' into C:\xampp\htdocs\ (or your web root).
3) Edit admin/config.php and user/config.php to set DB credentials if different.
4) Start XAMPP Apache & MySQL, then open:
   - Admin: http://localhost/board_result_project/admin/
     (login: admin / admin123)
   - User: http://localhost/board_result_project/user/
5) To import from Google Sheet:
   - Publish your Google Sheet to web as CSV (File -> Publish to web -> CSV).
   - Copy the CSV link and paste it into Admin -> Import from Google Sheet.
   - Or export CSV and paste CSV text in the textarea and Import.
6) After import, students and results are in MySQL and will be visible in User panel.
7) For PDF: open student's printable page and use browser Print -> Save as PDF.
