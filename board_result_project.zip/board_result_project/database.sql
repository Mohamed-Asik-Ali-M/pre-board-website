-- Database for board_results project
CREATE DATABASE IF NOT EXISTS board_results;
USE board_results;

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  roll_no VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  class VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT,
  subject VARCHAR(100),
  marks INT,
  total INT,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

/* Sample data - optional */
INSERT INTO students (roll_no,name,class) VALUES ('R001','Muthu','10A'),('R002','Anita','10A');
INSERT INTO results (student_id,subject,marks,total) VALUES (1,'Math',85,100),(1,'Science',78,100),(2,'Math',92,100);
